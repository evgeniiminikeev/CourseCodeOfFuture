public class Homework {
    public static void main(String[] args){

        System.out.printf("Площадь квадрата, с длиной стороны 5,5: %.2f%n", rectArea(5.4));
        System.out.printf("Площадь прямоугольника, с длиной 1,5 и высотой 9,3: %.2f%n", rectArea(1.5,9.3));

    }

    public static double rectArea(double length) {
        return length * length;
    }

    public static double rectArea(double length, double height) {
        return length * height;
    }
}
