import javax.swing.*;
import java.awt.*;

public class Homework {
    public static void main(String[] args) {
        JFrame frame = new JFrame();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setTitle("Copy text");
        frame.setSize(450, 100);
        frame.setLayout(new FlowLayout());
        frame.setResizable(false);

        JTextField field1 = new JTextField();
        field1.setPreferredSize(new Dimension(150, 50));

        JTextField field2 = new JTextField();
        field2.setPreferredSize(new Dimension(150, 50));

        JButton button = new JButton("Copy");
        button.setPreferredSize(new Dimension(100, 50));
        button.addActionListener(e -> field2.setText(field1.getText()));

        frame.add(field1);
        frame.add(field2);
        frame.add(button);

        frame.setVisible(true);
    }
}
