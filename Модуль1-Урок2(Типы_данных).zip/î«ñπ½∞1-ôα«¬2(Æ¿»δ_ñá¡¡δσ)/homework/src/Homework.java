import java.util.Scanner;

public class Homework {

    public static void main(String[] args) {

        Scanner scannerByte = new Scanner(System.in);
        Scanner scannerShort = new Scanner(System.in);
        Scanner scannerInt = new Scanner(System.in);
        Scanner scannerLong = new Scanner(System.in);
        Scanner scannerFloat = new Scanner(System.in);
        Scanner scannerDouble = new Scanner(System.in);
        Scanner scannerChar = new Scanner(System.in);
        Scanner scannerString = new Scanner(System.in);
        Scanner scannerBoolean = new Scanner(System.in);

        byte xByte;
        short xShort;
        int xInt;
        long xLong;
        float xFloat;
        double xDouble;
        char xChar;
        String xString;
        Boolean xBoolean;

        System.out.print("Введите значение типа byte: ");
        xByte = scannerByte.nextByte();
        System.out.println();

        System.out.print("Введите значение типа short: ");
        xShort = scannerShort.nextShort();
        System.out.println();

        System.out.print("Введите значение типа int: ");
        xInt = scannerInt.nextInt();
        System.out.println();

        System.out.print("Введите значение типа long: ");
        xLong = scannerLong.nextLong();
        System.out.println();

        System.out.print("Введите значение типа float: ");
        xFloat = scannerFloat.nextFloat();
        System.out.println();

        System.out.print("Введите значение типа double: ");
        xDouble = scannerDouble.nextDouble();
        System.out.println();

        System.out.print("Введите значение типа char: ");
        xChar = scannerChar.nextLine().charAt(0);
        System.out.println();

        System.out.print("Введите значение типа string: ");
        xString = scannerString.nextLine();
        System.out.println();

        System.out.print("Введите значение типа boolean: ");
        xBoolean = scannerBoolean.nextBoolean();
        System.out.println();        

        System.out.println
                ("Введенное значение типа byte: " + xByte +
                 "\nВведенное значение типа short: " + xShort +
                 "\nВведенное значение типа int: " + xInt +
                 "\nВведенное значение типа long: " + xLong +
                 "\nВведенное значение типа float: " + xFloat +
                 "\nВведенное значение типа double: " + xDouble +
                 "\nВведенное значение типа char: " + xChar +
                 "\nВведенное значение типа string: " + xString +
                 "\nВведенное значение типа boolean: " + xBoolean);

    }

}