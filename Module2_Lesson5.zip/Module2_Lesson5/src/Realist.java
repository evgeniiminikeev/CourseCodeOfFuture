public class Realist implements Philosopher {
    public String name;
    public Realist(String name) {
        this.name = name;
    }
    @Override
    public String makeConclusion(){
        return "Во вселенной есть только один уголок, который ты можешь уверенно взять в кандидаты на улучшение, это ты сам.";
    }
}
