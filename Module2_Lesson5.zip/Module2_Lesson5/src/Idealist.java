public class Idealist implements Philosopher{
    public String name;
    public Idealist(String name) {
        this.name = name;
    }

    @Override
    public String makeConclusion() {
        return "Познание духа есть самое конкретное и потому самое высокое и трудное.";
    }
}
