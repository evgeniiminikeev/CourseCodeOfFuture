public interface Philosopher {
    String makeConclusion();
}
