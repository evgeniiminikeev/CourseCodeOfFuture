public class Main {
    public static void main(String[] args) {
        Idealist idealist = new Idealist("Гегель");
        Realist realist = new Realist("Хаксли");

        System.out.println(idealist.name + ": " + idealist.makeConclusion());
        System.out.println(realist.name + ": " + realist.makeConclusion());
    }
}
