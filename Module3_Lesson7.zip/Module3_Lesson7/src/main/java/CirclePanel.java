import javax.swing.*;
import java.awt.*;
import java.awt.geom.Ellipse2D;

public class CirclePanel extends JPanel {
    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g;
        g2d.setColor(Color.CYAN);
        Ellipse2D circle = new Ellipse2D.Double(getWidth()/2 - 50, getHeight()/2 - 50, 100, 100);
        g2d.fill(circle);
    }
}
class CircleFrame extends JFrame {
    public CircleFrame() {
        super("Circle");
        setSize(300, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        CirclePanel panel = new CirclePanel();
        add(panel);
        setVisible(true);
    }
}

class CircleProgram {
    public static void main(String[] args) {
        CircleFrame frame = new CircleFrame();
    }
}
