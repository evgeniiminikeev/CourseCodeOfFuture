import jdk.jfr.Percentage;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

public class Homework {
    public static JPanel[][] panels;

    public static void main(String[] args) {
        JFrame frame = new JFrame();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setTitle("Шахматная доска");
        frame.setSize(800,800);
        frame.setLayout(new GridLayout(8,8));
        frame.setResizable(false);

        panels = new JPanel[8][8];
        for (int row = 0; row < 8; row++) {
            for (int col = 0; col < 8; col++) {
                panels[row][col] = new JPanel();
                panels[row][col].setPreferredSize(new Dimension(100,100));
                if ((row + col) % 2 == 0)
                    panels[row][col].setBackground(Color.BLACK);
                else
                    panels[row][col].setBackground(Color.WHITE);
                panels[row][col].addMouseListener(new PaneListener());
                frame.add(panels[row][col]);
            }
        }
        frame.setVisible(true);
    }

    public static class PaneListener implements MouseListener {
        @Override
        public void mouseClicked(MouseEvent e) {}
        @Override
        public void mousePressed(MouseEvent e) {}
        @Override
        public void mouseReleased(MouseEvent e) {}
        @Override
        public void mouseEntered(MouseEvent e) {
            for (int i = 0; i < 8; i ++) {
                for (int j = 0; j < 8; j ++) {
                    JPanel currentPanel = panels[i][j];
                    if (e.getSource() == currentPanel) {
                        currentPanel.setBorder(BorderFactory.createLineBorder(Color.GREEN, 10));
                    }
                }
            }
        }
        @Override
        public void mouseExited(MouseEvent e) {
            for (int i = 0; i < 8; i ++) {
                for (int j = 0; j < 8; j ++) {
                    JPanel currentPanel = panels[i][j];
                    if (e.getSource() == currentPanel) {
                        currentPanel.setBorder(null);
                    }
                }
            }
        }
    }
}
