import javax.swing.*;
import java.awt.*;

public class Homework {
    public static JPanel[][] panels;

    public static void main(String[] args) {
        JFrame frame = new JFrame();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setTitle("Шахматная доска");
        frame.setSize(800,800);
        frame.setLayout(new GridLayout(8,8));
        frame.setResizable(false);

        panels = new JPanel[8][8];
        for (int row = 0; row < 8; row++) {
            for (int col = 0; col < 8; col++) {
                panels[row][col] = new JPanel();
                panels[row][col].setPreferredSize(new Dimension(100,100));
                if ((row + col) % 2 == 0)
                    panels[row][col].setBackground(Color.BLACK);
                else
                    panels[row][col].setBackground(Color.WHITE);
                frame.add(panels[row][col]);
            }
        }
        frame.setVisible(true);
    }
}
