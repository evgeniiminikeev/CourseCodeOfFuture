import org.w3c.dom.Text;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;

public class TextFileViewer extends JFrame implements ActionListener {
    private JButton button;
    private JTextArea textArea;
    private JFileChooser fileChooser;

    public TextFileViewer() {
        super("Text File Viewer");

        button = new JButton("Choose a text file");
        button.addActionListener(this);

        textArea = new JTextArea(20, 40);
        textArea.setEditable(false);
        textArea.setLineWrap(true);

        fileChooser = new JFileChooser();

        JScrollPane scrollPane = new JScrollPane(textArea);
        add(button, BorderLayout.NORTH);
        add(scrollPane, BorderLayout.CENTER);

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        pack();
        setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == button) {
            int result = fileChooser.showOpenDialog(this);
            if (result == JFileChooser.APPROVE_OPTION) {
                File file = fileChooser.getSelectedFile();
                FileReader fr = null;
                BufferedReader br = null;
                try {
                    fr = new FileReader(file);
                    br = new BufferedReader(fr);
                    String line;
                    textArea.setText("");
                    while ((line = br.readLine()) != null) {
                        textArea.append(line + "\n");
                    }
                } catch (FileNotFoundException ex) {
                    textArea.setText("Файл не найден: " + ex.getMessage());
                } catch (IOException ex) {
                    textArea.setText("Ошибка ввода-вывода: " + ex.getMessage());
                } finally {
                    try {
                        if (br != null) br.close();
                        if (fr != null) fr.close();
                    } catch (IOException ex) {
                        textArea.setText("Ошибка ввода-вывода: " + ex.getMessage());
                    }
                }
            }
        }
    }

    public static void main(String[] args) {
        TextFileViewer viewer = new TextFileViewer();
        
    }
}
