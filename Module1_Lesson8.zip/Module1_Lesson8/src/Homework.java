import java.util.Scanner;

public class Homework {
    public static void main(String[] args){
        Scanner scanner = new Scanner(System.in);
        int num1,num2;

        System.out.print("Укажите число, которое хотите возвести в степень: ");
        num1 = scanner.nextInt();
        System.out.print("Укажите степень, в которую хотите возвести число: ");
        num2 = scanner.nextInt();

        System.out.printf("%d в степени %d = %d", num1, num2, power(num1,num2));
    }

    public static int power(int x, int y){
        return (y == 0) ? 1 : x * power(x,y-1);
    }
}
