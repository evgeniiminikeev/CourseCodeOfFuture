abstract public class Worker {
    String name;
    String occupation;
    int salary;
    public Worker(String name, String occupation, int salary) {
        this.name = name;
        this.occupation = occupation;
        this.salary = salary;
    }
    abstract public String myOccupation();
}
