public class Main {
    public static void main(String[] args) {
        Engineer engineer = new Engineer("Олегов Олег Олегович", 100000);
        System.out.println(engineer.myOccupation());
    }
}
