public class Engineer extends Worker{
    public Engineer(String name, int salary) {
        super(name, "Инженер", salary);
        System.out.println("Создан объект класса Engineer");
    }
    @Override
    public String myOccupation() {
        return name + " имеет профессию инженера с зарабной платой: " + salary + " руб.";
    }
}
