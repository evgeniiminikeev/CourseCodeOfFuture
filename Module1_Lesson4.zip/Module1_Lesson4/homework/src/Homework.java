import java.util.Scanner;

public class Homework {
    public static void main(String[] args) {

        Scanner scannerA = new Scanner(System.in);
        Scanner scannerB = new Scanner(System.in);

        System.out.print("Введите первое целое число: ");
        int numA = scannerA.nextInt();

        System.out.print("Введите второе целое число: ");
        int numB = scannerB.nextInt();

        // Переменная, в которую будут суммироваться введенные пользователем числа
        int sum = 0;

        // Нахожу меньшее число, чтобы в цикле указать числа в порядке от меньшего к большему
        int max = 0;
        if (numB < numA) {
            max = numA;
            numA = numB;
            numB = max;
        }

        for (int i = numA; i <= numB; i++) {
            sum += i;
        }

        System.out.println("Сумма всех целых чисел в отрезке от "+ numA +" до "+ numB +" равна: " + sum);

    }
}
