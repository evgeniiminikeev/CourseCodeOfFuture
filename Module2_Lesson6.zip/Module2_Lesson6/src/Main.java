import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        int x, y, z;
        Scanner scanner = new Scanner(System.in);

        System.out.print("Введите делимое и делитель: ");
        x = scanner.nextInt();
        y = scanner.nextInt();

        try {
            z = x / y;
            System.out.println(x + " / " + y + " = " + z);
        } catch (ArithmeticException e) {
            e.printStackTrace();
            System.out.println("Деление на ноль не имеет смысла!");
        }
    }
}
