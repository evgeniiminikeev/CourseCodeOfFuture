import java.lang.Math;

public class Homework {
    public static void main(String[] args) {
        /*
        Напишите программу, которая создает массив
        из 10-ти случайных целых чисел в
        диапазоне от 100 до 999 включительно и
        выводит на экран его элементы и их сумму.
         */

        // Инициализирую массив
        int[] list = new int[10];
        // Создаю счетчик суммы элементов массива
        int counter = 0;

        // Заполняю массив случайными элементами
        for (int i = 0; i < list.length; i++) {
            list[i] = 100 + (int) (Math.random() * 900);
            counter += list[i];
        }

        // Вывожу на экран элементы массива
        System.out.print("[");
        for (int i = 0; i < list.length; i++) {
            System.out.print(list[i]);
            if (i < list.length - 1) {
                System.out.print(", ");
            }
        }
        System.out.println("]");

        // Вывожу сумму всех элементов массива
        System.out.println("Сумма всех элементов массива равна " + counter);

    }
}
