/**
    ИСПОЛЬЗУЕТСЯ JAVA 11
*/


import java.util.Scanner;

public class Homework {

    public static void main(String[] args) {
        mainMenu();
    }

    public static void mainMenu(){
        Scanner scanner = new Scanner(System.in);
        int option;
        double number1, number2;
        boolean process = true;

        while (process) {
            System.out.println("Введите два действительных числа");

            System.out.print("Первое число: ");
            number1 = scanner.nextDouble();
            System.out.print("Второе число: ");
            number2 = scanner.nextDouble();

            System.out.println("\nВыберите операцию:");
            operationList();
            System.out.print("Выбор: ");
            option = scanner.nextInt();

            process = (option == 0) ? false : calculator(number1, number2, option);

        }

    }

    public static void operationList(){
        System.out.println("1.  +  (сложение)");
        System.out.println("2.  -  (вычитание)");
        System.out.println("3.  *  (умножение)");
        System.out.println("4.  /  (деление)");
        System.out.println("0. выход");
    }

    public static boolean calculator(double num1, double num2, int op) {
        System.out.println();
        switch(op) {
            case 1 : System.out.println(num1 + " + " + num2 + " = " + (num1+num2)); break;
            case 2 : System.out.println(num1 + " - " + num2 + " = " + (num1-num2)); break;
            case 3 : System.out.println(num1 + " * " + num2 + " = " + (num1*num2)); break;
            case 4 : System.out.println(num1 + " / " + num2 + " = " + (num1/num2)); break;
        }
        System.out.println();
        return true;
    }
}
