public class Main {
    public static void main(String[] args) {
        Rectangle rectangle = new Rectangle(5, 7);
        Parallelepiped parallelepiped = new Parallelepiped(2,5,8);

        System.out.println("Площадь прямоугольника: " + rectangle.getArea());
        System.out.println("Площадь параллелепипеда: " + parallelepiped.getArea());
        System.out.println("Объем параллелепипеда: " + parallelepiped.getVolume());
    }
}
