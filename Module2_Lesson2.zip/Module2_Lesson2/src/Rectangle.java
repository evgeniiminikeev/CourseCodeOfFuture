public class Rectangle {
    protected double length;
    protected double width;
    public Rectangle() {
        this.length = 0;
        this.width = 0;
    }
    public Rectangle(double length) {
        this.length = length;
        this.width = 0;
    }
    public Rectangle(double length, double width) {
        this.length = length;
        this.width = width;
    }
    public double getArea() {
        return length * width;
    }
}
