public class Parallelepiped extends Rectangle {
    protected double height;
    public Parallelepiped() {
        super();
        this.height = 0;
    }
    public Parallelepiped(double length) {
        super(length);
        this.height = 0;
    }
    public Parallelepiped(double length, double width) {
        super(length, width);
        this.height = 0;
    }
    public Parallelepiped(double length, double width, double height) {
        super(length, width);
        this.height = height;
    }
    @Override
    public double getArea() {
        double area = 2 * (
                length * width +
                width * height +
                height * length);
        return area;
    }
    public double getVolume() {
        return super.getArea()*height;
    }
}
