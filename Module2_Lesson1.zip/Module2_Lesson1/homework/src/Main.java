public class Main {
    public static void main(String[] args) {
        int[] marks1 = {5,3,4,4,3,5};
        int[] marks2 = {4,2,4,3,5,3,5,5};
        String name1 = "Oleg";
        String name2 = "Arkadij";

        Student student = new Student(name1, marks1);

        System.out.println("Имя студента: " + student.getName());
        System.out.println("Средний балл студента: " + student.getAverageMark());
        System.out.print("Список оценок студента: ");student.printMarks();

        System.out.println();
        student.setMarks(marks2);
        student.setName(name2);
        System.out.println("Имя студента: " + student.getName());
        System.out.println("Средний балл студента: " + student.getAverageMark());
        System.out.print("Список оценок студента: ");student.printMarks();
    }
}
