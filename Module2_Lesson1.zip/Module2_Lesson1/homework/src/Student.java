public class Student {
    // имя студента
    private String name;
    // список оценок студента
    private int[] marks;

    public Student(String name, int[] marks) {
        this.name = name;
        this.marks = new int[marks.length];

        // перебираю переданный массив для заполнения массива объекта
        for(int i=0; i<marks.length; i++) {
            this.marks[i] = marks[i];
        }
    }

    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public int[] getMarks() {
        return marks;
    }
    public void setMarks(int[] marks) {
        this.marks = new int[marks.length];
        for(int i=0; i<marks.length; i++) {
            this.marks[i] = marks[i];
        }
    }
    public void printMarks() {
        System.out.print("[");
        for(int i=0; i<marks.length; i++) {
            if (i == marks.length - 1) {
                System.out.print(marks[i]);
            } else {
                System.out.print(marks[i] + " ,");
            }
        }
        System.out.println("]");
    }
    public double getAverageMark() {
        double averageMark = 0;
        for(int i=0; i<marks.length; i++) {
            averageMark += marks[i];
        }
        averageMark /= marks.length;
        return averageMark;
    }
}
